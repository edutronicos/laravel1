

<?php $__env->startSection('title', 'Fotos'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center p-2">
            <h1>Excluir Eventos</h1>
    </div>
    
    <div class="container mt-5 mb-5">
    <form class="row g-3 needs-validation" action="/events/delete/<?php echo e($item->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <label for="inputText" class="form-label col-form-label-sm">Evento</label>
                    <input class="form-control form-control-sm" type="text" name="evento" value="<?php echo e($item->nome_evento); ?>">
                </div>
                <div class="col-md-4">
                    <label for="inputText" class="form-label col-form-label-sm">Local</label>
                    <input class="form-control form-control-sm" type="text" name="local" value="<?php echo e($item->local_evento); ?>">
                </div>
                <div class="col-md-4">
                    <label for="inputText" class="form-label col-form-label-sm">Data</label>
                    <input class="form-control form-control-sm" type="date" name="data" value="<?php echo e($item->data_evento); ?>">
                </div>
            </div>
            <div class="col-12 text-center">
                <h4>Tem certeza que deseja excluir este Evento?</h4>
            </div>
            <div class="col-12 text-center">
                <button class="btn btn-primary" type="submit">SIM</button>
            </div>
            
        </form><br>
        <div class="col-12 text-center">
                <a href="/photos"><button class="btn btn-primary">NÃO</button></a>
            </div>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\github\laravel1\resources\views/events/delete.blade.php ENDPATH**/ ?>