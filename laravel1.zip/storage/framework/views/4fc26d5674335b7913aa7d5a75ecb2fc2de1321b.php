


<?php $__env->startSection('title', 'Fotos'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center p-2">
            <h1>Lembranças</h1>
    </div>
    <div class="row text-center mt-5">
        
            <div class="col-12">
                <a href="/events/new" class="btn btn-primary">Enviar Fotos</a>
            </div>
       
        
    </div>

    <div class="container mt-5">
        <table class="table table-sm table-hover">
            <thead>
                <tr>
                    <th><a class="a" href="/ordenar/<?php echo e('evento'); ?>">Evento</a></th>
                    <th><a href="/ordenar/<?php echo e('local'); ?>">Local</a></th>
                    <th><a href="/ordenar/<?php echo e('data_evento'); ?>">Data</a></th>
                    <th>Ações</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="/events/view2/<?php echo e($itens->id); ?>"><?php echo e($itens->nome_evento); ?></a></td>
                    <td><?php echo e($itens->local_evento); ?></td>
                    <td><?php echo e($itens->data_evento); ?></td>
                    
                    <td><a href="/events/delete/<?php echo e($itens->id); ?>">Deletar<i class="bi bi-trash"></i></a> | <a href="/events/edit/<?php echo e($itens->id); ?>">Editar<i class="bi bi-pen"></i></a></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\github\laravel1\resources\views/events/index.blade.php ENDPATH**/ ?>