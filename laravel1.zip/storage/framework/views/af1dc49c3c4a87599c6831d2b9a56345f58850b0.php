

<?php $__env->startSection('title', 'Consulta'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center p-2">
        <h1>Cadastro de Funcionários</h1>
        
    </div>

    <div class="container mt-5">
            <table class="table table-sm table-hover">
                <thead>
                    <tr>
                    <th scope="col">Contrato</th>
                    <th scope="col">Cliente</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Local</th>
                    <th scope="col">Quem Cadastrou</th>
                    <th scope="col">ID</th>
                    <th scope="col">Ação</th>
                    </tr>
                </thead>
                <tbody>
        <?php $__currentLoopData = $cadastr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadastro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cadastro->contrato); ?></th>
                <td><?php echo e($cadastro->cliente); ?></td>
                <td><?php echo e($cadastro->nome_candidato); ?></td>
                <td><?php echo e($cadastro->local_unidade); ?></td>
                <td><?php echo e($cadastro->name); ?></td>
                <td><?php echo e($cadastro->id); ?></td>
                <td><a href="/recru/cadastro/<?php echo e($cadastro->id); ?>" class="btn btn-primary">Abrir</a></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\github\laravel1\resources\views/recru/lista.blade.php ENDPATH**/ ?>