

<?php $__env->startSection('title', 'Ramais'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center p-2">
            <h1>Editar Evento.</h1>
    </div>

    <div class="container mt-5 mb-5">
        <form class="row g-3 needs-validation" action="/events/edit/<?php echo e($item->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <label for="inputText" class="form-label col-form-label-sm">Nome</label>
                    <input class="form-control form-control-sm" type="text" name="nome" value="<?php echo e($item->nome_evento); ?>">
                </div>
                <div class="col-md-4">
                    <label for="inputText" class="form-label col-form-label-sm">Data de Nascimento</label>
                    <input class="form-control form-control-sm" type="date" name="data_nasc" value="<?php echo e($item->data_evento); ?>">
                </div>
            </div>
            <div class="col-12 text-center">
                <button class="btn btn-primary" type="submit">Salvar</button>
            </div>
        </form>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\github\laravel1\resources\views/events/edit.blade.php ENDPATH**/ ?>