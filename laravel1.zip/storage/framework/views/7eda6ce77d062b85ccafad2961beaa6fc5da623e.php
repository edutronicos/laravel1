

<?php $__env->startSection('title', 'E-mails'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center p-2">
            <h1>Relação de E-mails</h1>
    </div>
    <div class="row text-center mt-5">
        
            <div class="col-12">
                <a href="/emails/new" class="btn btn-primary">Novo E-mail</a>
            </div>
       
        
    </div>

    <div class="container mt-5">
        <table class="table table-sm table-hover">
            <thead>
                <tr>
                    <th><a class="a" href="/ordenar/<?php echo e('nome'); ?>">Nome</a></th>
                    <th><a href="/ordenar/<?php echo e('email'); ?>">E-mail</a></th>
                    <th><a href="/ordenar/<?php echo e('setor'); ?>">Setor</a></th>
                    <th><a href="/ordenar/<?php echo e('empresa'); ?>">Empresa</a></th>
                    <th>Ações</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($itens->nome); ?></td>
                    <td><a href="mailto:<?php echo e($itens->email); ?>"><?php echo e($itens->email); ?></a></td>
                    <td><?php echo e($itens->setor); ?></td>
                    <td><?php echo e($itens->empresa); ?></td>
                    <td><a href="/email/delete/<?php echo e($itens->id); ?>">Deletar<i class="bi bi-trash"></i></a> | <a href="/emails/edit/<?php echo e($itens->id); ?>">Editar<i class="bi bi-pen"></i></a></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\github\laravel1\resources\views/email/index.blade.php ENDPATH**/ ?>