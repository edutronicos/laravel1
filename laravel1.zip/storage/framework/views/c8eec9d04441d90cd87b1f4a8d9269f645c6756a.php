

<?php $__env->startSection('title', 'Ramais'); ?>

<?php $__env->startSection('content'); ?>

    <div class="text-center p-2">
            <h1>Adcionar novo ramal.</h1>
    </div>

    <div class="container mt-5 mb-5">
        <form class="row g-3 needs-validation" action="/branch/new" method="post" novalidate>
            <?php echo csrf_field(); ?>
            <div class="row justify-content-center">
                <div class="col-md-3">
                    <label for="inputText" class="form-label col-form-label-sm">Nome</label>
                    <input class="form-control form-control-sm" type="text" name="nome" id="nome" required>
                </div>
                <div class="col-md-2">
                    <label for="inputText" class="form-label col-form-label-sm">Setor</label>
                    <input class="form-control form-control-sm" type="text" name="setor" id="setor" required>
                </div>
                <div class="col-1">
                    <label for="inputText" class="form-label col-form-label-sm">Ramal</label>
                    <input class="form-control form-control-sm" type="text" name="ramal" id="ramal" required>
                </div>
            </div>

            <div class="row justify-content-center">
                
            </div>
            <div class="col-12 text-center">
                <button class="btn btn-primary" type="submit">Salvar Ramal</button>
            </div>
        </form>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\github\laravel1\resources\views/branch/create.blade.php ENDPATH**/ ?>