<h1>Crud Simples</h1>
<p>Cadastro de E-mails, com exibição em lista.</p>
<p>Cadastro de Ramais, com exibição em lista.</p>
<p>Index com atalhos uteis.</p>
<p>Cadastro de aniversários, exibindo na index só os aniversariantes do mês. Lista de aniversariantes cadastrados junto com o cadastro dos mesmos.</p>
<p>Upload de multiplas fotos, com cadastro do local e data.</p>
<p>Exibição de fotos usando carrocel bootstrap.</p>
<p>Cadastro de funcionários, exibição em lista dos cadastrados, com autenticação para acesso.</p>
<h3>Falta fazer.</h3>
<p>Requests de validação.</p>
<p>Incorporar agenda de compromissos.(FullCalendar)</p>
<p>Comentários na exibição das fotos.</p>
<h3>Login:</h3>
<p>administrador@email.com</p>
<p>12345678</p>